<ArcPad>
	<LAYER>
		<METADATA/>
		<SYMBOLOGY>
			<SIMPLELABELRENDERER field="EU_NAME" rotationfield="" visible="false" expression="" language="">
				<TEXTSYMBOL fontcolor="Black" font="Tahoma" fontstyle="regular" fontsize="9"/>
			</SIMPLELABELRENDERER>
			<SIMPLERENDERER>
				<SIMPLEMARKERSYMBOL color="PaleVioletRed" width="5" type="square" outlinewidth="1"/>
			</SIMPLERENDERER>
		</SYMBOLOGY>
		<QUERY where=""/>
		<FIELDHISTORY>
			<FIELDS>
				<FIELD name="EU_Name" value=""/>
				<FIELD name="EU_Code"/>
				<FIELD name="Northing"/>
				<FIELD name="Ten_km" value=""/>
				<FIELD name="Source" value=""/>
				<FIELD name="One_km" value=""/>
				<FIELD name="SAC_Name" value=""/>
				<FIELD name="SAC_Code" value=""/>
				<FIELD name="Notes_2" value=""/>
				<FIELD name="Accuracy" value=""/>
				<FIELD name="Notes" value=""/>
				<FIELD name="Year"/>
				<FIELD name="Site_Name" value=""/>
				<FIELD name="ID"/>
				<FIELD name="Pop_No" value=""/>
				<FIELD name="Date"/>
				<FIELD name="Easting"/>
			</FIELDS>
		</FIELDHISTORY>
	</LAYER>
</ArcPad>
